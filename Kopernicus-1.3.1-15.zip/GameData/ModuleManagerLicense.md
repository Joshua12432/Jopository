ModuleManager
=============


Original (c) from Ialdabaoth ( https://github.com/Ialdabaoth )

Modified by // Modifications by // Maintained by sarbian ( https://github.com/sarbian )


The original licence requirement was:

---

under a CC share-alike license. Anyone is free to do anything they like with ModuleManager's source, with two caveats:

1. You credit me as the original creator that your code is based on
2. You make it ABSOLUTELY CLEAR that your code is not the original ModuleManager, and that any problems that people have with your fork should be taken up with YOU, not me.

---


THIS IS NOT THE ORIGINAL MODULEMANAGER CODE.

Do not bother Ialdabaoth about any problems with it.
