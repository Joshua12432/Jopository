import unittest
from ..PietInterpreter.colors import possiblePixels


class PietTests(unittest.TestCase):

    def test_dummy(self) -> None:
        pp = possiblePixels()  # pylint: disable=unused-variable
        assert 1-1 == 0  # TODO
